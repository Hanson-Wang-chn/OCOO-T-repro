"""Deterministic run state, atomic checkpointing and append-only progress log."""
import datetime as dt
import json
import os
from pathlib import Path
import random
import fcntl
import hashlib
import numpy as np
import torch


def timestamp():
    return dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).isoformat(timespec='seconds')


def seed_all(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def file_sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(16<<20),b''):h.update(block)
    return h.hexdigest()


def rng_state():
    return {'python': random.getstate(), 'numpy': np.random.get_state(),
            'torch': torch.get_rng_state(), 'cuda': torch.cuda.get_rng_state_all()}


def restore_rng(s):
    random.setstate(s['python']); np.random.set_state(s['numpy'])
    torch.set_rng_state(s['torch']); torch.cuda.set_rng_state_all(s['cuda'])


def atomic_save(obj, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    with open(tmp, 'wb') as f:
        torch.save(obj, f); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)


def log_event(path, event):
    event = {'time': timestamp(), **event}
    with open(path, 'a') as f: f.write(json.dumps(event, ensure_ascii=False, allow_nan=False) + '\n')
    print(json.dumps(event, ensure_ascii=False, allow_nan=False), flush=True)


def edit_readme(transform):
    Path('logs').mkdir(exist_ok=True)
    with open('logs/readme.lock','a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        p=Path('README.md');tmp=p.with_suffix('.md.tmp')
        tmp.write_text(transform(p.read_text()));tmp.replace(p)


def readme_event(message,important=True):
    entry=f'\n- {timestamp()}：{message}\n'
    Path('logs').mkdir(exist_ok=True)
    with open('logs/progress_history.md','a') as history:history.write(entry)
    if important:edit_readme(lambda text:text+entry)


def update_readme_live(content):
    start='<!-- LIVE_TRAINING_START -->';end='<!-- LIVE_TRAINING_END -->'
    block=f'{start}\n\n{content}\n\n{end}'
    def replace(text):
        if start in text:return text[:text.index(start)]+block+text[text.index(end)+len(end):]
        return text+'\n'+block+'\n'
    edit_readme(replace)


class DualEMA:
    def __init__(self, model, decays=(0.9999, 0.9996)):
        self.decays = decays
        self.weights = [{n: p.detach().clone() for n, p in model.named_parameters()} for _ in decays]

    @torch.no_grad()
    def update(self, model):
        params = dict(model.named_parameters())
        for decay, weights in zip(self.decays, self.weights):
            torch._foreach_lerp_(list(weights.values()), [params[n] for n in weights], 1 - decay)

    def state_dict(self):
        return {str(d): {n: p.cpu() for n, p in w.items()} for d, w in zip(self.decays, self.weights)}

    def load_state_dict(self, states, device):
        self.weights = [{n: p.to(device) for n, p in states[str(d)].items()} for d in self.decays]

    @torch.no_grad()
    def copy_to(self, model, index=1):
        for n, p in model.named_parameters(): p.copy_(self.weights[index][n])

