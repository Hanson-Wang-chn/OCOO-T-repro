"""Registered near-zero candidates and the unchanged validation quality policy.

The paper does not specify a zero floor. Positive floors are explicit optional
reproduction choices, selected using full validation before any test generation.
"""
import json
import math
from pathlib import Path

import numpy as np

from .runtime import file_sha256


SUPPORTED_FLOORS = (0., .05)
METRIC_NAMES = ('PDCorr', 'DEOver', 'DEPrec', 'DirAgr', 'PDS_L1', 'PDS_L2', 'PDS_cos', 'MSE', 'MAE')
DEFAULT_THRESHOLDS = {
    'min_val_pdcorr': .35, 'min_val_pds': .75, 'min_val_pds_each': .70,
    'max_val_mse': .02, 'max_val_mae': .09, 'min_val_deover': .18,
    'min_val_deprec': .18, 'min_val_diragr': .70,
}


def zero_floor(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError('A registered numerical zero floor is required')
    value = float(value)
    if not math.isfinite(value) or value not in SUPPORTED_FLOORS:
        raise ValueError('Only the registered zero floors0 and0.05 are supported')
    return value


def apply_zero_floor(raw, floor):
    floor = zero_floor(floor)
    raw = np.asarray(raw)
    if raw.dtype not in (np.float32, np.float64) or not np.isfinite(raw).all():
        raise ValueError('Finite floating-point predictions required')
    # Preserve the legacy default operation exactly, including its dtype.
    return np.maximum(raw, 0) if floor == 0 else np.where(raw < floor, 0, raw)


def primary_score(metrics):
    return metrics['PDCorr'] + sum(metrics[k] for k in ('PDS_L1', 'PDS_L2', 'PDS_cos')) / 3


def quality_checks(metrics, thresholds=None):
    thresholds = DEFAULT_THRESHOLDS if thresholds is None else thresholds
    if set(thresholds) != set(DEFAULT_THRESHOLDS) or any(
            isinstance(v, bool) or not math.isfinite(v) or v < 0 for v in thresholds.values()):
        raise ValueError('Complete finite validation thresholds required')
    if set(metrics) != set(METRIC_NAMES) or any(not math.isfinite(float(v)) for v in metrics.values()):
        raise ValueError('All nine finite validation metrics required')
    pds = sum(metrics[k] for k in ('PDS_L1', 'PDS_L2', 'PDS_cos')) / 3
    return {'PDCorr': metrics['PDCorr'] >= thresholds['min_val_pdcorr'],
            'mean_PDS': pds >= thresholds['min_val_pds'],
            'MSE': metrics['MSE'] <= thresholds['max_val_mse'],
            'MAE': metrics['MAE'] <= thresholds['max_val_mae'],
            'DEOver': metrics['DEOver'] >= thresholds['min_val_deover'],
            'DEPrec': metrics['DEPrec'] >= thresholds['min_val_deprec'],
            'DirAgr': metrics['DirAgr'] >= thresholds['min_val_diragr'],
            **{k: metrics[k] >= thresholds['min_val_pds_each'] for k in ('PDS_L1', 'PDS_L2', 'PDS_cos')}}


def choose_feasible(candidates, thresholds=None):
    feasible = []
    for candidate in candidates:
        w = candidate.get('guidance')
        if (candidate.get('cap', 'missing') is not None or w is None
                or not math.isfinite(w) or w <= 0 or not candidate.get('clamp')):
            raise ValueError('Postprocessing selection requires full positive-CFG candidates')
        floor = zero_floor(candidate['zero_floor'])
        if all(quality_checks(candidate['metrics'], thresholds).values()):
            feasible.append(candidate)
    # Prefer the simpler original transformation when primary scores tie.
    return max(feasible, key=lambda r: (primary_score(r['metrics']), -r['zero_floor'])) if feasible else None


def verify_selection_postprocessing(selected, require_review=False):
    """Verify the optional layer added to the original calibration provenance."""
    floor = zero_floor(selected.get('zero_floor', 0.))
    proof = selected.get('postprocess_selection')
    if proof is None:
        if floor > 0 or require_review:
            raise ValueError('Registered full-validation postprocessing selection required')
        return floor
    for name in ('plan', 'review', 'candidate_metrics'):
        if file_sha256(proof[name + '_path']) != proof[name + '_sha256']:
            raise ValueError('Postprocessing selection evidence changed: ' + name)
    if (file_sha256('scripts/select_validation_postprocess.py') != proof['selector_sha256']
            or file_sha256(__file__) != proof['module_sha256']):
        raise ValueError('Postprocessing selection implementation changed')
    plan = json.loads(Path(proof['plan_path']).read_text())
    if plan['floors'] != list(SUPPORTED_FLOORS) or plan['quality_thresholds'] != DEFAULT_THRESHOLDS:
        raise ValueError('Postprocessing plan changed candidates or original quality thresholds')
    review = json.loads(Path(proof['review_path']).read_text())
    choice = review['selected']
    if choice is None or (choice['tag'], choice['zero_floor']) != (selected['tag'], floor):
        raise ValueError('Selection does not match the complete validation review')
    if review['thresholds'] != plan['quality_thresholds']:
        raise ValueError('Postprocessing review thresholds differ')
    best = choose_feasible(review['candidates'], review['thresholds'])
    if best is None or (best['tag'], best['zero_floor']) != (choice['tag'], floor):
        raise ValueError('Review did not select the best passing registered candidate')
    for key in ('guidance', 'cfg_min', 'cfg_max', 'cap', 'clamp'):
        if choice[key] != selected[key]:
            raise ValueError('Reviewed sampling settings changed: ' + key)
    checks = quality_checks(selected['metrics'], review['thresholds'])
    if not all(checks.values()) or choice['checks'] != checks:
        raise ValueError('Selected postprocessing failed an original full-validation check')
    saved = json.loads(Path(proof['candidate_metrics_path']).read_text())
    if set(saved) != set(METRIC_NAMES):
        raise ValueError('Selected metrics are incomplete')
    np.testing.assert_allclose([saved[k] for k in METRIC_NAMES],
                               [selected['metrics'][k] for k in METRIC_NAMES], rtol=0, atol=1e-10)
    np.testing.assert_allclose([choice['metrics'][k] for k in METRIC_NAMES],
                               [selected['metrics'][k] for k in METRIC_NAMES], rtol=0, atol=1e-10)
    return floor
