"""Read-only local progress; no heavy ML imports."""
import json
from pathlib import Path
import subprocess
import os


def status():
    files=sorted((p for p in Path('runs').glob('*/events.jsonl') if not p.parent.name.startswith('engine_smoke')),
                 key=lambda p:p.stat().st_mtime,reverse=True)
    if not files:return {'status':'no training events'}
    run=files[0].parent
    events=[]
    for line in files[0].read_text().splitlines():
        try:events.append(json.loads(line))
        except json.JSONDecodeError:pass
    train=next((e for e in reversed(events) if e['event']=='train'),{})
    val=next((e for e in reversed(events) if e['event']=='validation'),None)
    result={'run':str(run),'latest':events[-1] if events else None,'train':train,'validation':val,
            'finished':(run/'finished.json').exists()}
    ck=run/'checkpoint_state.json'
    if ck.exists():result['checkpoint']=json.loads(ck.read_text())
    pidfile=run/'training.pid'
    if pidfile.exists():
        try:
            pid=int(pidfile.read_text());result['pid']=pid
            result['pid_alive']=b'scripts/train.py' in Path(f'/proc/{pid}/cmdline').read_bytes() and Path(os.readlink(f'/proc/{pid}/cwd'))==Path.cwd()
        except (OSError,ValueError):result['pid_alive']=False
    pipeline=run/'pipeline_state.json'
    if pipeline.exists():result['pipeline']=json.loads(pipeline.read_text())
    generation=sorted(run.rglob('generation_state.json'),key=lambda p:p.stat().st_mtime)
    if generation:result['generation']=json.loads(generation[-1].read_text())
    return result


if __name__=='__main__':print(json.dumps(status(),ensure_ascii=False,indent=2))

