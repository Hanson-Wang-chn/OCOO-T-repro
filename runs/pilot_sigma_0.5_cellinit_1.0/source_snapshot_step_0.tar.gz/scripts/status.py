"""Read-only local progress; no heavy ML imports."""
import json
from pathlib import Path
import subprocess
import os


def process_state(pidfile,script):
    if not pidfile.exists():return {}
    try:
        pid=int(pidfile.read_text())
        alive=script.encode() in Path(f'/proc/{pid}/cmdline').read_bytes() and Path(os.readlink(f'/proc/{pid}/cwd'))==Path.cwd()
        return {'pid':pid,'alive':alive}
    except (OSError,ValueError):return {'alive':False}


def status():
    files=sorted((p for p in Path('runs').glob('*/events.jsonl') if not p.parent.name.startswith('engine_smoke')),
                 key=lambda p:p.stat().st_mtime,reverse=True)
    if not files:return {'status':'no training events'}
    run=files[0].parent
    events=[]
    for line in files[0].read_text().splitlines():
        try:events.append(json.loads(line))
        except json.JSONDecodeError:pass
    train=next((e for e in reversed(events) if e['event']=='train'),{})
    val=next((e for e in reversed(events) if e['event']=='validation'),None)
    result={'run':str(run),'latest':events[-1] if events else None,'train':train,'validation':val,
            'finished':(run/'finished.json').exists()}
    ck=run/'checkpoint_state.json'
    if ck.exists():result['checkpoint']=json.loads(ck.read_text())
    pidfile=run/'training.pid'
    training_process=process_state(pidfile,'scripts/train.py')
    if 'pid' in training_process:result['pid']=training_process['pid']
    if training_process:result['pid_alive']=training_process['alive']
    pipeline=run/'pipeline_state.json'
    if pipeline.exists():
        result['pipeline']=json.loads(pipeline.read_text())
        result['pipeline_process']=process_state(run/'pipeline.pid','scripts/run_experiment.py')
    generation=sorted(run.rglob('generation_state.json'),key=lambda p:p.stat().st_mtime)
    if generation:
        result['generation']=json.loads(generation[-1].read_text())
        result['generation_path']=str(generation[-1].parent)
    result['active']=bool(result.get('pid_alive') or result.get('pipeline_process',{}).get('alive'))
    return result


if __name__=='__main__':print(json.dumps(status(),ensure_ascii=False,indent=2))

