# 复现设计与未公开细节

原文：[arXiv:2606.12838v2](https://arxiv.org/abs/2606.12838v2)，本地 PDF/HTML 已保存。原模型无公开代码，本目录的 STATE、PerturbDiff、Cell Eval 源码只用于核对数据协议与指标，不作为 OCOO-T 实现。

## 明确保持的参数

短面板：2,000 HVG，不做 patch，不加入 VAE/OT/MMD；12 层、宽 768、12 头；RMSNorm、QK-RMSNorm、SwiGLU（ratio=4）、AdaLN-zero；从第 4 层起 32 个条件 token；冻结 5120 维 ESM2，经共享线性投影用于基因和遗传扰动；时间、扰动、细胞条件相加。图 1 还包含 positional encoding。

Rectified flow：`z_t=t*x+(1-t)*epsilon`，预测 `v=x-epsilon`，均方速度损失；`sigmoid(N(-0.8,0.8²))`；扰动和细胞条件独立以 0.1 概率置空（正文明确独立，附录只重述扰动 dropout）。AdamW β=(0.9,0.95)、weight_decay=0；有效批量 512、lr=1e-4、warmup=5 epoch、cosine 最小 lr=0；BF16；EMA=0.9999 / 0.9996，后者默认推理。Heun 50 步（50 个区间），最后一区间 Euler；CFG 严格使用式 11。

## 待确定项与选择依据（不声称是作者设置）

| 项目 | 实现 / 实验计划 | 依据与限制 |
| --- | --- | --- |
| 数据版本与拆分 | 核对 PerturbDiff 的公开压缩 H5AD + 官方固定 HVG + HepG2 留出列表；强制断言 Table 1 全部数量 | 论文明确沿用 STATE / PerturbDiff。压缩包解压 SHA256 必须等于 Arc 原发布文件。不能重新随机划分 |
| 原始 QC | 优先使用作者基准上游已做 efficacy 过滤的数据；检验归一化状态，避免二次 log | OCOO-T 未给出 efficacy 阈值。不会凭空重造过滤规则；此上游步骤属于复用已发布预处理结果 |
| 训练总轮数 | 上限 100，完整 5 epoch warmup；20 epoch 后结合验证集判断是否收敛，需要时延长/重训 | 附录未指定；Figure 5 有约 80 epoch 训练轨迹。总轮数是复现选择，不能写成原文参数 |
| SwiGLU 的 ratio 解释 | 采用 JiT 的参数匹配惯例：`int(768*4*2/3)=2048` | 论文引用 JiT 且多项模块与之相同；已核对 JiT 官方 `model_jit.py`。保留 literal=3072 选项用于诊断 |
| 连续值 MLP / 时间 | 值 MLP 1→768→768，SiLU；时间 256 维 sinusoid→768→768 | 两层 MLP 明确，内部宽度、激活、频率未明确；采用主干宽度与 JiT 时间编码 |
| 常规模块细节 | 线性层含 bias、Xavier uniform；RMSNorm eps=1e-6、可学习 scale；attention/FFN dropout=0；AdamW eps=1e-8 | 采用标准 JiT/PyTorch 惯例，原文未逐项给出；AdaLN 和输出头零初始化，time MLP / context position 初始 std=0.02 |
| 位置编码 / 条件 token | 固定一维 sincos；32 个可学习位置加扰动和细胞条件之和 | 图 1 位置编码明确但类型不明确；表达无空间网格，故不用图像二维 RoPE |
| batch 条件 | 默认包含 gem_group embedding，与 cell-line 合为一个上下文；细胞 dropout 时同时置空 | 正文默认包含 batch，但 Replogle 的具体注入细节未给出；保留开关比较 |
| 缺失 ESM2 | 大小写标准化 + HGNC 唯一旧名映射；其余用平均 ESM2 加可学习缺失基因身份，单独报告覆盖率 | 不伪造非编码基因的蛋白嵌入；保持不同缺失基因可区分。遗传扰动使用同一张表 |
| 噪声标准差 | 先比较 1.0 与 0.5，固定训练/验证噪声种子，选择去噪与生成均稳定的一组 | 公式包含 sigma，但原文未给数值；不在未检验时认定 1.0 最佳 |
| CFG 强度/区间 | 验证集比较普通条件场、原公式若干 w；候选区间 [0.1,0.9]、[0,1] | 式 11 中 w=1 不等于普通条件；按原式保留，不替换成常规单条件公式 |
| 表达后处理 | 默认保留生成实数，同时验证是否将负表达截为 0 更合理 | 原文未说明；仅在验证集选择，测试不用于决策 |
| 单卡等效 | 实测 microbatch，梯度累积到 512；Flash SDPA、可选 activation checkpoint / torch.compile | 不改变模型、损失或有效批量；累积步才更新优化器及两组 EMA |
| 评估细节 | 优先直接调用公开 Cell Eval；固定基因顺序、相同真实对照、按扰动宏平均 | 论文未锁工具版本；记录代码来源版本/哈希。明确目标基因排除和 DE 测试实现 |

## 已完成检查与小实验方案

- 确认公开压缩 H5AD 与 Arc 原文件逐字节相同；严格复现 Table 1 所有细胞数及验证/测试扰动数；训练/验证/测试 (cell line, perturbation) 组合不重叠。
- X_hvg 均值 0.4354，基因内标准差汇总 0.4553；不进行额外标准化或放大。固定原 2,000 HVG，不因缺失 ESM2 改变基因集合。
- 使用 56 个原始 gem_group 标签，与正文统计一致。不同 cell line 的同号 batch 由独立 cell-line 条件区分；曾检查组合后会有 215 个组合，但未采用 215-label 方案训练。
- 训练平均表达基线在验证集 PDCorr=0.4172、MSE=0.00782、PDS_L2=0.5097。说明单靠总体表达误差不能证明扰动预测有效；模型选择需同时看 PDCorr 和 PDS。
- 性能测试：完整 12×768 模型，microbatch 16/32 编译后均约 73 cells/s；32 的峰值约 29.2 GB，16 约 15.6 GB。64 即便 activation checkpoint 仍 OOM（编译器选择的重计算方案），不用于训练。选择 16×32 次累积，显存裕量支持双 EMA 和中途验证。
- 噪声小实验：同一随机种子、同一 16,384 训练子集，sigma=1.0 与 0.5 各 12 epoch（384 个优化步），均保留 5 epoch warmup、有效 batch=512 和双 EMA。全验证集固定 1,024 细胞做去噪探针；最终全部 60 个验证扰动每扰动最多 16 个细胞做 50 步生成。
- 384 步远小于 EMA 的有效时间尺度，故**小实验生成使用原始权重作诊断**，并同时记录原始/EMA 去噪误差；小实验原始权重不允许作为最终测试复现模型。完整训练与正式推理使用 EMA=0.9996。这里不是将 pilot 指标冒充论文结果。
- 在正式全量训练前，把小实验扩展为 sigma∈{1,0.5} × time_scale∈{1,1000} 共 4 组。原因：原文未说明时间嵌入频率；JiT 的 raw t 编码来自 x-pred，而本文默认是更依赖时间条件的 v-pred。需要检验 raw t 的弱变化是否影响收敛，不能在长训练后才发现。两种时间缩放只作用于网络的 sinusoid 编码；flow 路径和时间采样仍严格为原文的 [0,1] 与 logit-normal。其余参数、训练子集及随机种子相同。
- 训练引擎 smoke test 已通过；checkpoint 测试还验证恢复优化器、两组 EMA、CPU/GPU 随机状态后下一步精确一致。每 50 个优化步及每 epoch 原子写检查点，故普通中断最多损失约 6 分钟计算；SIGTERM/SIGINT 在当前优化步后安全保存。
- 训练按细胞均匀随机采样、不放回，逐轮用独立确定性置乱；全量每轮 1,118 个完整 512-cell batch，末尾 129 个细胞当轮不使用，下一轮重新置乱。这是未公开的 sampler / drop-last 细节，保持有效 batch 与 EMA 更新定义一致；验证/测试无丢弃。梯度裁剪默认关闭（原文未指定），但每优化步检查 loss / gradient finite，异常时保留上一份有效检查点。

## 来源

- Arc 数据：https://huggingface.co/datasets/arcinstitute/Replogle-Nadig-Preprint
- PerturbDiff 数据（仅 Replogle）：https://huggingface.co/datasets/katarinayuan/PerturbDiff_data ，commit `10654f24cfb539d619e8221ec61eb7e878364cec`
- 基准参考：https://github.com/DeepGraphLearning/PerturbDiff 、https://github.com/ArcInstitute/state
- ESM2/UCE 原文件镜像：https://huggingface.co/minwoosun/uce-misc ，commit `bffb91084e4476698984e7e01f6170ce291f4074`；验证 SHA256
- HGNC：https://storage.googleapis.com/public-download-files/hgnc/tsv/tsv/hgnc_complete_set.txt （下载快照，保存校验值）
- JiT：https://github.com/LTH14/JiT/blob/main/model_jit.py （仅核对标准模块惯例）
- 指标：https://github.com/ArcInstitute/cell-eval



## 指标实现核对

使用 Cell Eval 0.8.2 / pdex 0.3.0，保存完整源码及环境锁。已额外下载论文发布日期前的 Cell Eval commit `44f9009d6f3d4a4f944cba333c96ed258dd0d973`（0.7.2）：9 项论文指标的核心算法与当前版本相同，`_types/_anndata.py` 逐字节相同，DE 排序/重合与方向实现相同；后续新增 ceiling 等功能不参与本实验。当前 wrapper 固定 epsilon=0、关闭 CPM filter，保持旧版 DE 默认行为。3 个真实验证扰动的 identity smoke test 得到 PDCorr≈1、全部 PDS/DE=1、MSE=MAE=0，确认评估路径贯通。

Cell Eval 的入口会拒绝负表达。对于未截断的生成诊断，只直接调用同一工具的 array metric 函数，避免自动变换；正式 DE 评估要求非负表达。生成原始预测始终保存，是否截断只由验证集决定并单独记录。

中途生成的 cap 只限制预测细胞数；真实参考始终使用对应扰动的全部验证细胞，以减少选择配置时的参考均值噪声。每次评估保存 `population_counts.json` 和真实索引。正式测试不设 cap，生成数与全部 26,878 个测试扰动细胞一致。

全量训练在第 1、2 轮额外做每扰动最多 8 个细胞的原始权重生成诊断，专门检查条件是否学好；它不参与正式最佳模型选择。正式验证每 5 轮使用 EMA=0.9996、每扰动最多 32 个预测细胞；推理校准与测试均禁止使用原始诊断权重。采样前先保存已完成训练的检查点。启用非负后处理时，另存 `prediction_raw.npy`，避免只保留截断后的结果。

全量训练收敛规则：至少 20 epoch，最多 100；正式验证评分为 PDCorr + 三种 PDS 的均值。评分连续 10 epoch 没有达到 0.002 的改善时停止；最佳权重仍保留实际最高评分，不受该最小改善阈值影响。两个早停状态随检查点保存。该规则用于原文未公开的训练长度选择，原文明确的模型、批量、学习率缩放、warmup 和损失参数保持不变。A100 热稳态约 65–70 cells/s，全量每轮约 2.3–2.5 小时。

训练集同基因跨细胞系平均效应的额外诊断（只评估验证集，非 OCOO-T）：

|效应缩放|PDCorr|PDS_L2|MSE|
|---|---|---|---|
|effect_transfer_0.0|0.4172|0.5097|0.00782|
|effect_transfer_0.25|0.4501|0.5672|0.00721|
|effect_transfer_0.5|0.4549|0.6211|0.00710|
|effect_transfer_1.0|0.4176|0.7114|0.00838|

这说明数据中存在可转移扰动信号，但简单转移的 PDS 仍明显低于论文 0.853；这些结果仅用于诊断训练是否学到扰动特异性，不替代 Transformer 训练，也不使用测试表达调参。

首组 step 352 的条件量级诊断已保存：gene condition RMS≈0.232、基因间 std≈0.100、cell embedding RMS≈0.024、time embedding RMS≈0.859、t=0 与 t=1 之间差异 RMS≈0.079。没有据此额外插入论文未指定的条件归一化层；继续用预设时间编码对照与实际生成结果判断。

## 首组生成失败的诊断与修正对照

sigma=1 / time_scale=1 / cell_init_std=0.02 的 384 步短试跑：速度验证 MSE=0.4173，但生成 PDCorr=-0.0177、PDS_L2=0.5078、MSE=0.07931；截断负值也未解决（PDCorr=-0.0100、MSE=0.07767）。预测整体均值/标准差为 0.4100/0.6275，真实验证集为 0.4106/0.6593，所以不能只看整体均值和方差。

训练集细胞系均值作诊断时，960 个预测细胞中最近均值属于 HepG2 的为 0，Jurkat/K562/RPE1 分别为 88/516/356；这是质心诊断，不是独立细胞系分类器。结果指向短试跑没有充分利用目标 cell-line 条件，尚不足以评价原模型最终能力。

新增与首组严格配对的 `cell_init_std=1.0` 对照（PyTorch Embedding 的标准正态尺度）；原文未公开初始化，因此比较它与 JiT 风格 0.02，保留原架构、损失、全部原文训练参数和相同数据/噪声种子。没有通过替换模型、缩短 ODE 或改变测试拆分来规避失败。噪声/时间的既定四组继续；第五组随后顺序运行。所有性能判断仍只来自验证集。

重新加载原始权重、不使用 compile，按相同种子重新生成首 32 个细胞，与缓存的编译生成结果 RMSE=0.00184、平均绝对差=0.00072，远小于当前表达误差；排除了主导性的权重交换/编译推理偏差。另按式 11 检查 t=0 条件速度场对 w 的响应（`cfg_boundary_probe.json`）；这只是边界诊断，不把未运行的完整 CFG 轨迹当作评估结果。

训练集单独统计（不含验证/测试/对照）已保存：mean=0.4361，within-gene std RMS=0.4572，global std=0.6797；没有据此重新归一化。噪声/初始化选择只比较验证结果。恢复测试同时验证 CPU 模型的下一优化步、双 EMA 和 GPU 随机数序列可恢复。

## 文献版本核对

2026-11-17 04:38 重新核对版本：最初默认 PDF 已是 v2（2026-08-14，SHA256 `ad55f9fc7a6d5d053cacf103559108e19f2f2e40ef0d068ff09445b2ca33dd9f`），而当时 HTML 为 v1，README 的 v1 标签不准确，现已纠正。已分别固定下载两版 PDF 与 v2 HTML，保存 `paper_version_manifest.json` 和 `version_diff.txt`。逐项核对，§3 设计、Table 1 / Table 3 数字与 Appendix A 训练参数未变；差异主要为作者列表与分页/图文位置。主基准继续以固定 v2 PDF 为准，已有小实验配置无需因此变更。旧 HTML 和文本另存 `OCOO-T_v1_html.*`。

## 长面板数据的来源歧义

Table 5 / §4.3 将 18,080-gene 输入称为 Replogle–Nadig，§3.5 又称来自 AIVC 并引用 [23] Virtual Cell Challenge。已核对 Arc 官方数据仓库说明：该引用的数据是 H1 hESC（约 300,000 cells / 300 targets），并非本次 Table 1 的四细胞系 Replogle–Nadig。固定公开 `replogle.h5ad` 只有 6,642 个 X 基因、2,000 个固定 HVG，不能恢复不存在的 18,080 维。来源证据：https://github.com/ArcInstitute/arc-virtual-cell-atlas/blob/main/virtual-cell-challenge/README.md 。因此先完成能精确核对数据和划分的 Table 3 主基准，不把另一个 H1 数据集或补零的伪长面板冒充 Table 5 复现；此项歧义与尚未运行的 control-context / MMD 消融会在最终范围中明确列出。

## 有限生成数量的采样误差诊断

`python scripts/bootstrap_reference.py` 在验证集每个扰动的经验分布内有放回抽样，4 个固定种子，按相同 Cell Eval 协议对照完整验证参考。cap=8/16/32 的平均 MSE 为 0.01570/0.00771/0.00388，PDCorr 为 0.554/0.676/0.779，PDS_L2 约为 0.994/1.000/1.000。由于重采样来源和参考共享经验分布，这只是抽样波动诊断，并非独立泛化成绩或严格性能上限。它表明当前 pilot 的 MSE≈0.04–0.08、PDS≈0.5 不能用生成数量少来解释；同时，不能把 cap 评估的绝对误差直接与全量测试表格比较。原始表格保存在 `runs/validation_sampling_reference/`。

## 轮末评估的中断恢复修复

2026-11-17 05:54 检查发现，原先先保存完成 epoch 的优化步、再进行生成评估；若此时中断，恢复会从下一 epoch（或直接结束）开始，可能跳过未完成的评估。现将 `pending_generation_epoch` 纳入原子检查点；恢复先完成待办评估，复用已刷盘生成批次，再继续训练。评估前后恢复全部 RNG，完成标记原子替换；完成的 run 重复启动不会重训，`--fresh` 要求新目录以保留已有产物。新增真实 CUDA 训练/采样集成测试，分别故意在中间 epoch 和最后 epoch 的第二批生成抛错，验证只补齐缺失批次、优化步不重复、最佳权重与 RNG 恢复正确。9 项测试全部通过（`logs/tests_pending_evaluation.log`）。这是恢复逻辑修复，不改变模型、损失和既定超参数；正在运行的第五组未中断，原过程继续。

## 初始化对照的结果与下一步

第五组（sigma=1 / time_scale=1 / cell_init_std=1）在相同 384 步预算下，原始权重验证生成 PDCorr=0.2179、MSE=0.01366、PDS_L2=0.5208；目标 HepG2 最近训练质心比例从 0/960 提高到 960/960，预测 bulk 到 HepG2 训练均值 MSE 由 0.0620 降至 0.00105。说明此未知初始化影响短期条件学习，强初始化更合适。但组内表达方差约为真实验证的 0.65 倍，PDS 仍接近随机；不能据此宣称扰动预测成功。

补充配对对照 sigma=0.5 / time_scale=1 / cell_init_std=1（第六组），其余配置、子集、种子、384 步预算不变。仅比较原始权重的生成诊断，正式全量推理仍用 EMA=0.9996。选型主要依据验证 PDCorr + 三种 PDS 均值，同时检查表达误差、条件质心与方差，避免把全局均值拟合或过度收缩当作扰动学习。
