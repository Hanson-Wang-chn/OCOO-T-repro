"""Read-only local progress; no heavy ML imports."""
import json
from pathlib import Path
import subprocess


def status():
    files=sorted(Path('runs').glob('*/events.jsonl'),key=lambda p:p.stat().st_mtime,reverse=True)
    if not files:return {'status':'no training events'}
    run=files[0].parent
    events=[]
    for line in files[0].read_text().splitlines():
        try:events.append(json.loads(line))
        except json.JSONDecodeError:pass
    train=next((e for e in reversed(events) if e['event']=='train'),{})
    val=next((e for e in reversed(events) if e['event']=='validation'),None)
    result={'run':str(run),'latest':events[-1] if events else None,'train':train,'validation':val,
            'finished':(run/'finished.json').exists()}
    ck=run/'checkpoint_state.json'
    if ck.exists():result['checkpoint']=json.loads(ck.read_text())
    generation=sorted(run.glob('validation_epoch_*/generation_state.json'),key=lambda p:p.stat().st_mtime)
    if generation:result['generation']=json.loads(generation[-1].read_text())
    return result


if __name__=='__main__':print(json.dumps(status(),ensure_ascii=False,indent=2))

