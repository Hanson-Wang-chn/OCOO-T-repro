from types import SimpleNamespace
import json
import numpy as np
import pytest
import torch
import ocoot.evaluate as evaluation


@pytest.mark.skipif(not torch.cuda.is_available(),reason='GPU sampling entrypoint')
def test_sampling_keeps_raw_values_and_resumes_without_recomputation(tmp_path,monkeypatch):
    calls=[]
    def fake_sample(model,p,c,b,n_genes,**kwargs):
        calls.append(kwargs['seed'])
        return torch.tensor([-1.,0.,2.],device=p.device).repeat(len(p),1)
    monkeypatch.setattr(evaluation,'sample',fake_sample)
    monkeypatch.setattr(evaluation,'update_readme_live',lambda message:None)
    data=SimpleNamespace(x=np.zeros((4,3)),meta={key:np.zeros(4,dtype=np.int64) for key in ['pert','cell','batch']})
    model=SimpleNamespace(eval=lambda:None);indices=np.arange(4)
    result=evaluation.generate(model,data,indices,tmp_path,batch_size=2,clamp=True)
    np.testing.assert_array_equal(result,np.tile([0.,0.,2.],(4,1)))
    np.testing.assert_array_equal(np.load(tmp_path/'prediction_raw.npy'),np.tile([-1.,0.,2.],(4,1)))
    assert len(calls)==2
    result2=evaluation.generate(model,data,indices,tmp_path,batch_size=2,clamp=True)
    np.testing.assert_array_equal(result2,result)
    assert len(calls)==2
    assert json.loads((tmp_path/'generation_state.json').read_text())['completed']==4
    statistics=json.loads((tmp_path/'sample_statistics.json').read_text())
    assert statistics['raw']['negative_fraction']==1/3
    assert statistics['evaluated']['negative_fraction']==0
    with pytest.raises(ValueError,match='different options'):
        evaluation.generate(model,data,indices,tmp_path,batch_size=2,clamp=True,guidance=2.)

