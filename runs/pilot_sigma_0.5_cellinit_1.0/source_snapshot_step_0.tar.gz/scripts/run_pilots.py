"""Sequential pilots, so a long first run cannot leave the GPU idle afterward."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def main():
    p=argparse.ArgumentParser();p.add_argument('--wait-pid',type=int);a=p.parse_args()
    Path('logs/pilots.pid').write_text(str(os.getpid()))
    if a.wait_pid:
        while True:
            try:os.kill(a.wait_pid,0)
            except ProcessLookupError:break
            time.sleep(15)
    trials=['sigma_1.0','sigma_0.5','sigma_1.0_t1000','sigma_0.5_t1000','sigma_1.0_cellinit_1.0','sigma_0.5_cellinit_1.0']
    for trial in trials:
        run=Path(f'runs/pilot_{trial}')
        if (run/'finished.json').exists():continue
        with open(f'logs/pilot_{trial}.log','a') as log:
            subprocess.run([sys.executable,'scripts/train.py','--config',f'configs/pilot_{trial}.yaml'],stdout=log,stderr=log,check=True)
    results={}
    for trial in trials:
        path=Path(f'runs/pilot_{trial}/validation_epoch_012')
        results[trial]=json.loads((path/'metrics/summary.json').read_text())
        # Report nonnegative postprocessing from the same generated cells.
        import numpy as np
        from ocoot.data import BenchmarkData
        from ocoot.evaluate import official_metrics
        data=BenchmarkData();idx=np.load(path/'indices.npy');pred=np.load(path/'prediction.npy',mmap_mode='r')
        results[trial]['clamped']=official_metrics(data,idx,np.maximum(pred,0),path/'metrics_clamped')
        results[trial]['negative_fraction']=float((pred<0).mean())
    Path('runs/pilot_comparison.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(results,indent=2),flush=True)


if __name__=='__main__':main()

