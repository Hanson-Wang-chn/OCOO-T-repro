"""Estimate capped-generation sampling variability from validation only.

This empirical-distribution resampling diagnostic is optimistic about the true
distribution and is neither an independent test nor a model performance ceiling.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from ocoot.data import BenchmarkData
from ocoot.evaluate import official_metrics


def main():
    p=argparse.ArgumentParser();p.add_argument('--seeds',type=int,default=4)
    p.add_argument('--outdir',default='runs/validation_sampling_reference');a=p.parse_args()
    torch.set_num_threads(4)
    data=BenchmarkData();root=Path(a.outdir);root.mkdir(parents=True,exist_ok=True)
    rows=[]
    for cap in [8,16,32]:
        idx=data.evaluation_indices('validation',cap)
        for seed in range(a.seeds):
            out=root/f'cap_{cap}_seed_{seed}'
            if (out/'summary.json').exists():metrics=json.loads((out/'summary.json').read_text())
            else:
                rng=np.random.default_rng(7719+seed)
                pred=np.empty((len(idx),data.x.shape[1]),dtype=np.float32)
                for pert in np.unique(data.meta['pert'][idx]):
                    positions=np.flatnonzero(data.meta['pert'][idx]==pert)
                    pool=data.val[data.meta['pert'][data.val]==pert]
                    drawn=rng.choice(pool,len(positions),replace=True)
                    pred[positions]=data.x[drawn]
                metrics=official_metrics(data,idx,pred,out)
            rows.append({'cap':cap,'seed':seed,**metrics})
    frame=pd.DataFrame(rows);frame.to_csv(root/'resamples.csv',index=False)
    stats=frame.drop(columns='seed').groupby('cap').agg(['mean','std'])
    stats.to_csv(root/'summary.csv')
    (root/'protocol.json').write_text(json.dumps({
        'split':'validation only','seeds':a.seeds,'caps':[8,16,32],
        'procedure':'Sample with replacement within each empirical validation perturbation; compare with the fixed full validation reference.',
        'limitations':'The empirical reference is shared. This is not independent test performance or a rigorous ceiling.',
        'purpose':'Quantify sampling variability at pilot/periodic-validation cell caps, not select or fit a prediction model.',
    },indent=2))
    print(stats.to_string())


if __name__=='__main__':main()
