import pytest

from ocoot.distributed import microbatch_shard


@pytest.mark.parametrize('world_size, counts', [(1, [32]), (2, [16, 16]),
                                               (3, [11, 11, 10]), (4, [8, 8, 8, 8])])
def test_global_batch_shards_cover_each_cell_with_uniform_weight(world_size, counts):
    shards = [microbatch_shard(512, 16, world_size, rank) for rank in range(world_size)]
    assert [len(shard) for shard in shards] == counts
    assert [batch for shard in shards for batch in shard] == list(range(32))
    # DDP averages rank losses, so rank loss sums need the world-size factor
    # regardless of how many microbatches that rank was assigned.
    expected = sum(range(32)) / 32
    actual = sum(sum(shard) * world_size / 32 for shard in shards) / world_size
    assert actual == pytest.approx(expected)
